<?php
$servername = "localhost";//adatbázis szerver neve
$username = "root";//felhasználó név
$password = "";//jelszó
$dbname = "techscape";//adatbázi név
// Kapcsolódás az adatbázishoz
$conn = new mysqli($servername, $username, $password, $dbname);
// Ellenőrizzük a kapcsolatot
if ($conn->connect_error) {
    die("Hiba történt az adatbázisoh való csatlakozás során: " . $conn->connect_error);
}
// Az űrlapról érkező adatok kezelése
$nev = $_POST['nev'];
$email = $_POST['email'];
$uzenet = $_POST['uzenet'];
// SQL lekérdezés az adatok beszúrásához az adatbázisba
$sql = "INSERT INTO uzenetek (nev, email, uzenet) VALUES ('$nev', '$email', '$uzenet')";
if ($conn->query($sql) === TRUE) {
    echo "Az adatokat sikeresen mentettük az adatbázisba.";
} else {
    echo "Hiba történt az adatok mentése közben: " . $conn->error;
}
// Kapcsolat bezárása
$conn->close();
?>